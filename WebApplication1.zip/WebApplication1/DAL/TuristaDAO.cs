﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Web;
using WebApplication1.Models;

namespace WebApplication1.DAL
{
    public class TuristaDAO
    {
        public int incluirTurista(Turista turista)
        {
            return 0;
        }
    }
}